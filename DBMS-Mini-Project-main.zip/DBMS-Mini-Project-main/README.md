# DBMS-Mini-Project
College Placement Management System

Design Idea: The system has web-forms like registration forms, login forms and account pages. It includes the following main modules: 

• Admin Module.
• Company Module.
• Student Module.

An administrator has full authority over the whole system. The administrator is able to retrieve data of the registered students, placed students and approve the companies. The students can register themselves for placement or internship of the approved Companies.
